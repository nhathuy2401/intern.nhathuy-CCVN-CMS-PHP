<?php
$host = 'db';
$db_name = 'cms-dtb';
$db_user = 'root';
$db_pass = '123123';

try{
    $conn = new PDO("mysql:host=$host;dbname=$db_name",$db_user,$db_pass);
    $conn->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e){
    echo "Connect Error : ".$e->getMessage();
}
