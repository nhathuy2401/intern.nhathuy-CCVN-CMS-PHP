<?php
require_once 'Database.php';
function redirect_To($new_location){
    header('Location: '.$new_location);
    exit;
}

function checkUserNameExist($UserName){
    global  $conn;
    $sql = "SELECT username FROM admins WHERE username= :username";
    $stmt = $conn->prepare($sql);
    $stmt->bindValue(':username',$UserName);
    $stmt->execute();
    if($stmt->rowCount()>0){
        return true ;
    } else {
        return false;
    }

}
function login_Attempt($UserName,$Password){
      global $conn ;
      $sql = "SELECT * FROM admins WHERE username=:username AND password =:password";
      $stmt = $conn->prepare($sql);
      $stmt->bindValue(':username',$UserName);
      $stmt->bindValue(':password',$Password);
      $stmt->execute();

      $result = $stmt->rowCount();

      if($result == 1 ){
          return $found_account = $stmt->fetch();
      } else {
          return null ;
      }


}
?>
