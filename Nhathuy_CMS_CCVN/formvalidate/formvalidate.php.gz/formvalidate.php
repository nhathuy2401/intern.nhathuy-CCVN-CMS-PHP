<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="form.css" >
</head>
<body>
<?php
$input_name = ($_POST['input_name']);
$input_email = ($_POST['input_email']);
$input_gender = ($_POST['input_gender']);
$input_website =($_POST['input_website']);
$submit_button = $_POST['submit_button'];
$name_Error = "";
$email_Error = "";
$gender_Error = "";
$website_Error = "";
if(empty($input_name)){
    $name_Error = "Required Name";
} elseif (!preg_match("/^[a-zA-Z0-9]*$/",$input_name)){
    $name_Error = "Letter and whitespace is not allowed";
}
if(empty($input_email)){
    $email_Error="Required Email";
} elseif (!preg_match("/[a-zA-Z0-9._-]{3,}@[a-zA-Z0-9._-]{3,}[.]{1}[a-zA-Z0-9._-]{2,}/",$input_email)){
    $email_Error = "Invalid Email";
}
if (empty($input_gender)){
    $gender_Error = "*Required Gender";
}
if(empty($input_website)){
    $website_Error="Required Website";
} elseif(!preg_match("/(https:|ftp:)\/\/+[a-zA-Z0-9.\-_\/?\$=&\#\~`!]+\.[a-zA-Z0-9.\-_\/?\$=&\#\~`!]*/",$input_website)){
    $website_Error ="Invalid website";
}




?>
<h1>Information form</h1>
<?php
if(!empty($input_name)&& !empty($input_email) && !empty($input_website)){
    if ((preg_match("/^[a-zA-Z0-9]*$/",$input_name) ==true)
        &&(preg_match("/[a-zA-Z0-9._-]{3,}@[a-zA-Z0-9._-]{3,}[.]{1}[a-zA-Z0-9._-]{2,}/",$input_email))
        &&preg_match("/(https:|ftp:)\/\/+[a-zA-Z0-9.\-_\/?\$=&\#\~`!]+\.[a-zA-Z0-9.\-_\/?\$=&\#\~`!]*/",$input_website)){

        echo "Your Name : $input_name <br>";
        echo "Your Email : $input_email <br>";
        echo "Gender : $input_gender<br>";
        echo "Your Website: $input_website <br>";

    }
    }
else {
    echo "Please filling and submit form";
}


?>
<form action="" method="post">
    <p>
        <label for="input_name">Name:</label>
        <input type="text" name="input_name" id="input_name">
        <span class="error"><?= $name_Error?></span>


    </p>
    <p>
        <label for="input_email">Email:</label>
        <input type="email" id="input_email" name="input_email">
        <span class="error"><?= $email_Error?></span>
    </p>
    <p>
        <label for="input_gender">Gender:</label>


        <input type="radio" value="Female" name="input_gender"> Female
        <input type="radio" value="Male" name="input_gender"> Male
        <span class="error"><?= $gender_Error?></span>

    </p>
    <p>
        <label for="input_website">Website: </label>
        <input type="text" id="input_website" name="input_website">
        <span class="error"><?= $website_Error?></span>


    </p>
    <input type="submit" name="submit_button">


</form>
</body>
</html>