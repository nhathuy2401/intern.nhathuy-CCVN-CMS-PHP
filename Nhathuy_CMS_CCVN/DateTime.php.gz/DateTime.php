<?php
date_default_timezone_set("Asia/Bangkok");
$currentTime = time();
$dateTime = strftime("%D-%M-%Y");
echo $dateTime;
