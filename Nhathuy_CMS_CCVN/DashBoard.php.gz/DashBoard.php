<?php
require_once "Include/Sessions.php";
echo errorMessage();
echo successMessage();